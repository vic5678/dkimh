package com.vicsapplication.app.modules.resultscreen.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityResultScreenBinding
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.resultscreen.`data`.viewmodel.ResultScreenVM
import kotlin.String
import kotlin.Unit

class ResultScreenActivity :
    BaseActivity<ActivityResultScreenBinding>(R.layout.activity_result_screen) {
  private val viewModel: ResultScreenVM by viewModels<ResultScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.resultScreenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtBacktohomepag.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "RESULT_SCREEN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ResultScreenActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
