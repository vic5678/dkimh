package com.vicsapplication.app.modules.homepagescreenseven.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreenseven.`data`.model.HomepageScreenSevenModel
import org.koin.core.KoinComponent

class HomepageScreenSevenVM : ViewModel(), KoinComponent {
  val homepageScreenSevenModel: MutableLiveData<HomepageScreenSevenModel> =
      MutableLiveData(HomepageScreenSevenModel())

  var navArguments: Bundle? = null
}
