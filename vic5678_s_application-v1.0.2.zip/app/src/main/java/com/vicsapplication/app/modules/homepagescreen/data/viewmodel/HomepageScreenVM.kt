package com.vicsapplication.app.modules.homepagescreen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreen.`data`.model.HomepageScreenModel
import org.koin.core.KoinComponent

class HomepageScreenVM : ViewModel(), KoinComponent {
  val homepageScreenModel: MutableLiveData<HomepageScreenModel> =
      MutableLiveData(HomepageScreenModel())

  var navArguments: Bundle? = null
}
