package com.vicsapplication.app.modules.homepagescreensix.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreensix.`data`.model.HomepageScreenSixModel
import org.koin.core.KoinComponent

class HomepageScreenSixVM : ViewModel(), KoinComponent {
  val homepageScreenSixModel: MutableLiveData<HomepageScreenSixModel> =
      MutableLiveData(HomepageScreenSixModel())

  var navArguments: Bundle? = null
}
