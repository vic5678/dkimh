package com.vicsapplication.app.modules.howitworksscreen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.howitworksscreen.`data`.model.HowItWorksScreenModel
import org.koin.core.KoinComponent

class HowItWorksScreenVM : ViewModel(), KoinComponent {
  val howItWorksScreenModel: MutableLiveData<HowItWorksScreenModel> =
      MutableLiveData(HowItWorksScreenModel())

  var navArguments: Bundle? = null
}
