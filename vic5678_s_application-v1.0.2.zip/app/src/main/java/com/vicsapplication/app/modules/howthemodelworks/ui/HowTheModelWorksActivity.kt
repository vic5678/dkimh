package com.vicsapplication.app.modules.howthemodelworks.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHowTheModelWorksBinding
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.homepagescreensix.ui.HomepageScreenSixActivity
import com.vicsapplication.app.modules.howthemodelworks.`data`.viewmodel.HowTheModelWorksVM
import kotlin.String
import kotlin.Unit

class HowTheModelWorksActivity :
    BaseActivity<ActivityHowTheModelWorksBinding>(R.layout.activity_how_the_model_works) {
  private val viewModel: HowTheModelWorksVM by viewModels<HowTheModelWorksVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.howTheModelWorksVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageMenu.setOnClickListener {
      val destIntent = HomepageScreenSixActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtIDerma.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOW_THE_MODEL_WORKS_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HowTheModelWorksActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
