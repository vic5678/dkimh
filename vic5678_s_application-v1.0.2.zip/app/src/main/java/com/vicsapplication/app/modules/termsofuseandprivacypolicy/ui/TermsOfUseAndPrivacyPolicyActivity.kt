package com.vicsapplication.app.modules.termsofuseandprivacypolicy.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityTermsOfUseAndPrivacyPolicyBinding
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.homepagescreenseven.ui.HomepageScreenSevenActivity
import com.vicsapplication.app.modules.termsofuseandprivacypolicy.`data`.viewmodel.TermsOfUseAndPrivacyPolicyVM
import kotlin.String
import kotlin.Unit

class TermsOfUseAndPrivacyPolicyActivity :
    BaseActivity<ActivityTermsOfUseAndPrivacyPolicyBinding>(R.layout.activity_terms_of_use_and_privacy_policy)
    {
  private val viewModel: TermsOfUseAndPrivacyPolicyVM by viewModels<TermsOfUseAndPrivacyPolicyVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.termsOfUseAndPrivacyPolicyVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageMenu.setOnClickListener {
      val destIntent = HomepageScreenSevenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtIDerma.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "TERMS_OF_USE_AND_PRIVACY_POLICY_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, TermsOfUseAndPrivacyPolicyActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
