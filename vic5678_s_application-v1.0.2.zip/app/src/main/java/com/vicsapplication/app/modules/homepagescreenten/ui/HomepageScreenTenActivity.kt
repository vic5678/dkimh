package com.vicsapplication.app.modules.homepagescreenten.ui

import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHomepageScreenTenBinding
import com.vicsapplication.app.modules.aboutemb.ui.AboutembActivity
import com.vicsapplication.app.modules.applicationinfo.ui.ApplicationInfoActivity
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.homepagescreenten.`data`.viewmodel.HomepageScreenTenVM
import com.vicsapplication.app.modules.howthemodelworks.ui.HowTheModelWorksActivity
import com.vicsapplication.app.modules.loginscreen.ui.LoginScreenActivity
import com.vicsapplication.app.modules.termsofuseandprivacypolicy.ui.TermsOfUseAndPrivacyPolicyActivity
import com.vicsapplication.app.modules.termsofuseandprivacypolicyone.ui.TermsOfUseAndPrivacyPolicyOneActivity
import kotlin.String
import kotlin.Unit

class HomepageScreenTenActivity :
    BaseActivity<ActivityHomepageScreenTenBinding>(R.layout.activity_homepage_screen_ten) {
  private val viewModel: HomepageScreenTenVM by viewModels<HomepageScreenTenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.homepageScreenTenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtWhothemodelw.setOnClickListener {
      val destIntent = HowTheModelWorksActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtAboutEMB.setOnClickListener {
      val destIntent = AboutembActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtTermsofuse.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguage.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtIDerma.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      // TODO please, add your navigation code here
      finish()
    }
    binding.txtLogout.setOnClickListener {
      val destIntent = LoginScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtApplicationInf.setOnClickListener {
      val destIntent = ApplicationInfoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOMEPAGE_SCREEN_TEN_ACTIVITY"

  }
}
