package com.vicsapplication.app.modules.shootpicturescreen.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityShootPictureScreenBinding
import com.vicsapplication.app.modules.analyzescreen.ui.AnalyzeScreenActivity
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.howitworksscreen.ui.HowItWorksScreenActivity
import com.vicsapplication.app.modules.shootpicturescreen.`data`.viewmodel.ShootPictureScreenVM
import kotlin.String
import kotlin.Unit

class ShootPictureScreenActivity :
    BaseActivity<ActivityShootPictureScreenBinding>(R.layout.activity_shoot_picture_screen) {
  private val viewModel: ShootPictureScreenVM by viewModels<ShootPictureScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.shootPictureScreenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtContinue.setOnClickListener {
      val destIntent = AnalyzeScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtBack.setOnClickListener {
      val destIntent = HowItWorksScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtBackOne.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "SHOOT_PICTURE_SCREEN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ShootPictureScreenActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
