package com.vicsapplication.app.modules.mainmenuone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityMainMenuOneBinding
import com.vicsapplication.app.modules.mainmenuone.`data`.viewmodel.MainMenuOneVM
import kotlin.String
import kotlin.Unit

class MainMenuOneActivity :
    BaseActivity<ActivityMainMenuOneBinding>(R.layout.activity_main_menu_one) {
  private val viewModel: MainMenuOneVM by viewModels<MainMenuOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.mainMenuOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "MAIN_MENU_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MainMenuOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
