package com.vicsapplication.app.modules.doctorsscreen.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class DoctorSScreenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBack: String? = MyApp.getInstance().resources.getString(R.string.lbl_back2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDrBoulidis: String? = MyApp.getInstance().resources.getString(R.string.lbl_dr_boulidis)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOccupationDer: String? =
      MyApp.getInstance().resources.getString(R.string.msg_occupation_der)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmailAddress: String? = MyApp.getInstance().resources.getString(R.string.lbl_email_address)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmail: String? = MyApp.getInstance().resources.getString(R.string.msg_boulidis_gmail)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAvailableHours: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_available_hours)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt9001700: String? = MyApp.getInstance().resources.getString(R.string.lbl_9_00_17_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt9001700One: String? = MyApp.getInstance().resources.getString(R.string.lbl_9_00_17_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt9001700Two: String? = MyApp.getInstance().resources.getString(R.string.lbl_9_00_17_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt9001700Three: String? = MyApp.getInstance().resources.getString(R.string.lbl_9_00_17_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt9001700Four: String? = MyApp.getInstance().resources.getString(R.string.lbl_9_00_17_00)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPhone: String? = MyApp.getInstance().resources.getString(R.string.lbl_phone)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt2310836973: String? = MyApp.getInstance().resources.getString(R.string.lbl_2310_836_973)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMakeanewScan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_make_a_new_scan)

)
