package com.vicsapplication.app.modules.landingscreen.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityLandingScreenBinding
import com.vicsapplication.app.modules.landingscreen.`data`.viewmodel.LandingScreenVM
import com.vicsapplication.app.modules.loginscreen.ui.LoginScreenActivity
import kotlin.String
import kotlin.Unit

class LandingScreenActivity :
    BaseActivity<ActivityLandingScreenBinding>(R.layout.activity_landing_screen) {
  private val viewModel: LandingScreenVM by viewModels<LandingScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.landingScreenVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = LoginScreenActivity.getIntent(this, null)
      startActivity(destIntent)
      }, 3000)
    }

    override fun setUpClicks(): Unit {
      binding.linearLandingScreen.setOnClickListener {
        val destIntent = LoginScreenActivity.getIntent(this, null)
        startActivity(destIntent)
      }
    }

    companion object {
      const val TAG: String = "LANDING_SCREEN_ACTIVITY"

    }
  }
