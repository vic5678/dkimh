package com.vicsapplication.app.modules.aboutemb.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityAboutembBinding
import com.vicsapplication.app.modules.aboutemb.`data`.viewmodel.AboutembVM
import com.vicsapplication.app.modules.mainmenu.ui.MainMenuActivity
import kotlin.String
import kotlin.Unit

class AboutembActivity : BaseActivity<ActivityAboutembBinding>(R.layout.activity_aboutemb) {
  private val viewModel: AboutembVM by viewModels<AboutembVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.aboutembVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageMenu.setOnClickListener {
      val destIntent = MainMenuActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ABOUTEMB_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AboutembActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
