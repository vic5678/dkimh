package com.vicsapplication.app.modules.doctorsscreen.ui

import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityDoctorSScreenBinding
import com.vicsapplication.app.modules.doctorsscreen.`data`.viewmodel.DoctorSScreenVM
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.homepagescreenone1.ui.HomepageScreenOne1Activity
import com.vicsapplication.app.modules.howitworksscreen.ui.HowItWorksScreenActivity
import kotlin.String
import kotlin.Unit

class DoctorSScreenActivity :
    BaseActivity<ActivityDoctorSScreenBinding>(R.layout.activity_doctor_s_screen) {
  private val viewModel: DoctorSScreenVM by viewModels<DoctorSScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.doctorSScreenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.frameHome.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.frameProfile.setOnClickListener {
      val destIntent = HomepageScreenOne1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearNewscan.setOnClickListener {
      val destIntent = HowItWorksScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "DOCTOR_S_SCREEN_ACTIVITY"

  }
}
