package com.vicsapplication.app.modules.homepagescreenone.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class HomepageScreenOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGoodmorning: String? = MyApp.getInstance().resources.getString(R.string.lbl_good_morning)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAristotelia: String? = MyApp.getInstance().resources.getString(R.string.lbl_aristotelia)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLatestresults: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_latest_results)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNothingSuspici: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nothing_suspici)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMakeanewScan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_make_a_new_scan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCloseDoctors: String? = MyApp.getInstance().resources.getString(R.string.lbl_close_doctors)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtFunFacts: String? = MyApp.getInstance().resources.getString(R.string.lbl_fun_facts)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOurheartbeats: String? =
      MyApp.getInstance().resources.getString(R.string.msg_our_heart_beats)

)
