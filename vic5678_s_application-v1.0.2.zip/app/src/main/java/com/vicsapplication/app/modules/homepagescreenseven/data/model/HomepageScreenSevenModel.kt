package com.vicsapplication.app.modules.homepagescreenseven.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class HomepageScreenSevenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAboutEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_about_emb)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtApplicationInf: String? =
      MyApp.getInstance().resources.getString(R.string.msg_application_inf)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWhothemodelw: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_the_model_w)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_terms_of_use2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTermsofuse: String? = MyApp.getInstance().resources.getString(R.string.lbl_privacy_policy2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLogout: String? = MyApp.getInstance().resources.getString(R.string.lbl_logout)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMadebyEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_made_by_emb)

)
