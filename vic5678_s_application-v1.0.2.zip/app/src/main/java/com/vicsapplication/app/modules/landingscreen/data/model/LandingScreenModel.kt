package com.vicsapplication.app.modules.landingscreen.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class LandingScreenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_emb)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAristotleUnive: String? =
      MyApp.getInstance().resources.getString(R.string.msg_aristotle_unive)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTaptocontinue: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_tap_to_continue)

)
