package com.vicsapplication.app.modules.howthemodelworks.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.howthemodelworks.`data`.model.HowTheModelWorksModel
import org.koin.core.KoinComponent

class HowTheModelWorksVM : ViewModel(), KoinComponent {
  val howTheModelWorksModel: MutableLiveData<HowTheModelWorksModel> =
      MutableLiveData(HowTheModelWorksModel())

  var navArguments: Bundle? = null
}
