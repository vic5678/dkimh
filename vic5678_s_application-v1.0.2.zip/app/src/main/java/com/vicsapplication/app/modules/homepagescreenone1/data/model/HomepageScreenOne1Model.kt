package com.vicsapplication.app.modules.homepagescreenone1.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class HomepageScreenOne1Model(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAristoteliaPal: String? =
      MyApp.getInstance().resources.getString(R.string.msg_aristotelia_pal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOccupationStu: String? =
      MyApp.getInstance().resources.getString(R.string.msg_occupation_stu)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmailAddress: String? = MyApp.getInstance().resources.getString(R.string.lbl_email_address)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEmail: String? = MyApp.getInstance().resources.getString(R.string.msg_aristotelis_pal2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBirthDate: String? = MyApp.getInstance().resources.getString(R.string.lbl_birth_date)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDate: String? = MyApp.getInstance().resources.getString(R.string.lbl_30_10_2000)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMakeanewScan: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_make_a_new_scan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBack: String? = MyApp.getInstance().resources.getString(R.string.lbl_back2)

)
