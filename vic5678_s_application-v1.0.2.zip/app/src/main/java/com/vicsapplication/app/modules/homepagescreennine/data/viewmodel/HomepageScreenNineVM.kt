package com.vicsapplication.app.modules.homepagescreennine.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreennine.`data`.model.HomepageScreenNineModel
import org.koin.core.KoinComponent

class HomepageScreenNineVM : ViewModel(), KoinComponent {
  val homepageScreenNineModel: MutableLiveData<HomepageScreenNineModel> =
      MutableLiveData(HomepageScreenNineModel())

  var navArguments: Bundle? = null
}
