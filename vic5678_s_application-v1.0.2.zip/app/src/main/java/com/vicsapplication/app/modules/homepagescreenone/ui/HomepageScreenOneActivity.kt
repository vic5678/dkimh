package com.vicsapplication.app.modules.homepagescreenone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHomepageScreenOneBinding
import com.vicsapplication.app.modules.homepagescreenone.`data`.viewmodel.HomepageScreenOneVM
import com.vicsapplication.app.modules.homepagescreenone1.ui.HomepageScreenOne1Activity
import com.vicsapplication.app.modules.homepagescreentwo.ui.HomepageScreenTwoActivity
import com.vicsapplication.app.modules.howitworksscreen.ui.HowItWorksScreenActivity
import kotlin.String
import kotlin.Unit

class HomepageScreenOneActivity :
    BaseActivity<ActivityHomepageScreenOneBinding>(R.layout.activity_homepage_screen_one) {
  private val viewModel: HomepageScreenOneVM by viewModels<HomepageScreenOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.homepageScreenOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.floatingBtnFloatingactionbutton.setOnClickListener {
      val destIntent = HomepageScreenOne1Activity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.linearNewscan.setOnClickListener {
      val destIntent = HowItWorksScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageMenu.setOnClickListener {
      val destIntent = HomepageScreenTwoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOMEPAGE_SCREEN_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HomepageScreenOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
