package com.vicsapplication.app.modules.resultscreen.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ResultScreenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBack: String? = MyApp.getInstance().resources.getString(R.string.lbl_back)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtResults: String? = MyApp.getInstance().resources.getString(R.string.lbl_results2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDisease: String? = MyApp.getInstance().resources.getString(R.string.lbl_disease)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDyshidroticecz: String? =
      MyApp.getInstance().resources.getString(R.string.msg_dyshidrotic_ecz)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTreatment: String? = MyApp.getInstance().resources.getString(R.string.lbl_treatment)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_moisturizing_lo)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBacktohomepag: String? =
      MyApp.getInstance().resources.getString(R.string.msg_back_to_homepag)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_let_s_find_you)

)
