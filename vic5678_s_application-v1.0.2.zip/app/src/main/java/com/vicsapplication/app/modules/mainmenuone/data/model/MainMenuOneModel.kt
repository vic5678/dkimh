package com.vicsapplication.app.modules.mainmenuone.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class MainMenuOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMadebyEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_emb)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHomepage: String? = MyApp.getInstance().resources.getString(R.string.lbl_homepage)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtApplicationInf: String? = MyApp.getInstance().resources.getString(R.string.lbl_faq)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_terms_of_use2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTermsofuse: String? = MyApp.getInstance().resources.getString(R.string.lbl_privacy_policy)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAboutEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_about_emb)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLogout: String? = MyApp.getInstance().resources.getString(R.string.lbl_logout)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLogoutOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_close)

)
