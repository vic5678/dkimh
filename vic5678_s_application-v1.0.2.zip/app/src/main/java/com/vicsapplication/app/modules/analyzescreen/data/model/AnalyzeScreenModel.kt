package com.vicsapplication.app.modules.analyzescreen.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AnalyzeScreenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPlease: String? = MyApp.getInstance().resources.getString(R.string.lbl_please)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWaitforthere: String? =
      MyApp.getInstance().resources.getString(R.string.msg_wait_for_the_re2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_fun_facts_our_h)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTheyareReady: String? =
      MyApp.getInstance().resources.getString(R.string.msg_they_are_ready)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtContinue: String? = MyApp.getInstance().resources.getString(R.string.lbl_continue)

)
