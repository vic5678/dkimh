package com.vicsapplication.app.modules.homepagescreenten.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreenten.`data`.model.HomepageScreenTenModel
import org.koin.core.KoinComponent

class HomepageScreenTenVM : ViewModel(), KoinComponent {
  val homepageScreenTenModel: MutableLiveData<HomepageScreenTenModel> =
      MutableLiveData(HomepageScreenTenModel())

  var navArguments: Bundle? = null
}
