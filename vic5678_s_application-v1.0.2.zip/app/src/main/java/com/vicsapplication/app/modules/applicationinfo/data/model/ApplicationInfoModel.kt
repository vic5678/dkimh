package com.vicsapplication.app.modules.applicationinfo.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class ApplicationInfoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtApplicationInf: String? =
      MyApp.getInstance().resources.getString(R.string.msg_application_inf)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? = MyApp.getInstance().resources.getString(R.string.msg_name_iderma_de)

)
