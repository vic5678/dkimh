package com.vicsapplication.app.modules.homepagescreen.ui

import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHomepageScreenBinding
import com.vicsapplication.app.modules.homepagescreen.`data`.viewmodel.HomepageScreenVM
import com.vicsapplication.app.modules.mainmenuone.ui.MainMenuOneActivity
import kotlin.String
import kotlin.Unit

class HomepageScreenActivity :
    BaseActivity<ActivityHomepageScreenBinding>(R.layout.activity_homepage_screen) {
  private val viewModel: HomepageScreenVM by viewModels<HomepageScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.homepageScreenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtMore.setOnClickListener {
      val destIntent = MainMenuOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOMEPAGE_SCREEN_ACTIVITY"

  }
}
