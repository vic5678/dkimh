package com.vicsapplication.app.modules.aboutemb.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class AboutembModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_emb)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTeamMembers: String? = MyApp.getInstance().resources.getString(R.string.lbl_team_members)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBoard: String? = MyApp.getInstance().resources.getString(R.string.lbl_board)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsada: String? = MyApp.getInstance().resources.getString(R.string.lbl_nick_beglis)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_sofia_georgiou)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaTwo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_christina_athan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_athina_keramido)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMembers: String? = MyApp.getInstance().resources.getString(R.string.lbl_members)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaFour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_ioannis_marios)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaFive: String? =
      MyApp.getInstance().resources.getString(R.string.msg_athina_aggelopo)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaSix: String? =
      MyApp.getInstance().resources.getString(R.string.msg_michaela_verver)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaSeven: String? =
      MyApp.getInstance().resources.getString(R.string.msg_filippos_margar)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaEight: String? =
      MyApp.getInstance().resources.getString(R.string.msg_chrysovalantis)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaNine: String? =
      MyApp.getInstance().resources.getString(R.string.msg_maria_ouzounido)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaTen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_nikoleta_soulio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaEleven: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_maria_deli)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaTwelve: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_despoina_deli)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaThirteen: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_theodora_gazea)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaFourteen: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_georgios_rizos)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaFifteen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_iasonas_zakynth)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaSixteen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_victoria_galano)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaSeventeen: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_andreas_segani)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaEighteen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_ioannis_georgou)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAsdasdasdsadaNineteen: String? =
      MyApp.getInstance().resources.getString(R.string.msg_aristotelis_pal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.msg_emb_social_medi)

)
