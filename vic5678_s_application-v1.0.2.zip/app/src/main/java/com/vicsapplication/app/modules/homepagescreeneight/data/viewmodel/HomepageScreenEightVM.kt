package com.vicsapplication.app.modules.homepagescreeneight.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreeneight.`data`.model.HomepageScreenEightModel
import org.koin.core.KoinComponent

class HomepageScreenEightVM : ViewModel(), KoinComponent {
  val homepageScreenEightModel: MutableLiveData<HomepageScreenEightModel> =
      MutableLiveData(HomepageScreenEightModel())

  var navArguments: Bundle? = null
}
