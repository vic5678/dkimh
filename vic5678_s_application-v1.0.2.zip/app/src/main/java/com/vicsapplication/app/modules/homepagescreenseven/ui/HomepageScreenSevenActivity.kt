package com.vicsapplication.app.modules.homepagescreenseven.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHomepageScreenSevenBinding
import com.vicsapplication.app.modules.aboutemb.ui.AboutembActivity
import com.vicsapplication.app.modules.applicationinfo.ui.ApplicationInfoActivity
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.homepagescreenseven.`data`.viewmodel.HomepageScreenSevenVM
import com.vicsapplication.app.modules.howthemodelworks.ui.HowTheModelWorksActivity
import com.vicsapplication.app.modules.loginscreen.ui.LoginScreenActivity
import com.vicsapplication.app.modules.termsofuseandprivacypolicy.ui.TermsOfUseAndPrivacyPolicyActivity
import kotlin.String
import kotlin.Unit

class HomepageScreenSevenActivity :
    BaseActivity<ActivityHomepageScreenSevenBinding>(R.layout.activity_homepage_screen_seven) {
  private val viewModel: HomepageScreenSevenVM by viewModels<HomepageScreenSevenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.homepageScreenSevenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtTermsofuse.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      // TODO please, add your navigation code here
      finish()
    }
    binding.txtLogout.setOnClickListener {
      val destIntent = LoginScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtApplicationInf.setOnClickListener {
      val destIntent = ApplicationInfoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtIDerma.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtAboutEMB.setOnClickListener {
      val destIntent = AboutembActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguage.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtWhothemodelw.setOnClickListener {
      val destIntent = HowTheModelWorksActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOMEPAGE_SCREEN_SEVEN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HomepageScreenSevenActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
