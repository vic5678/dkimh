package com.vicsapplication.app.modules.aboutemb.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.aboutemb.`data`.model.AboutembModel
import org.koin.core.KoinComponent

class AboutembVM : ViewModel(), KoinComponent {
  val aboutembModel: MutableLiveData<AboutembModel> = MutableLiveData(AboutembModel())

  var navArguments: Bundle? = null
}
