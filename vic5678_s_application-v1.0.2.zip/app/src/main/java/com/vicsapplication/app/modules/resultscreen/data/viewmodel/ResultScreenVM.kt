package com.vicsapplication.app.modules.resultscreen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.resultscreen.`data`.model.ResultScreenModel
import org.koin.core.KoinComponent

class ResultScreenVM : ViewModel(), KoinComponent {
  val resultScreenModel: MutableLiveData<ResultScreenModel> = MutableLiveData(ResultScreenModel())

  var navArguments: Bundle? = null
}
