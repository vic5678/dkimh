package com.vicsapplication.app.modules.homepagescreeneight.ui

import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHomepageScreenEightBinding
import com.vicsapplication.app.modules.homepagescreeneight.`data`.viewmodel.HomepageScreenEightVM
import com.vicsapplication.app.modules.loginscreen.ui.LoginScreenActivity
import kotlin.String
import kotlin.Unit

class HomepageScreenEightActivity :
    BaseActivity<ActivityHomepageScreenEightBinding>(R.layout.activity_homepage_screen_eight) {
  private val viewModel: HomepageScreenEightVM by viewModels<HomepageScreenEightVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.homepageScreenEightVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageClose.setOnClickListener {
      // TODO please, add your navigation code here
      finish()
    }
    binding.txtLogout.setOnClickListener {
      val destIntent = LoginScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOMEPAGE_SCREEN_EIGHT_ACTIVITY"

  }
}
