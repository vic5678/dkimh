package com.vicsapplication.app.modules.termsofuseandprivacypolicyone.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class TermsOfUseAndPrivacyPolicyOneModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTermsofusean: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_privacy_policy2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? = MyApp.getInstance().resources.getString(R.string.msg_iderma_inc_is)

)
