package com.vicsapplication.app.modules.landingscreen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.landingscreen.`data`.model.LandingScreenModel
import org.koin.core.KoinComponent

class LandingScreenVM : ViewModel(), KoinComponent {
  val landingScreenModel: MutableLiveData<LandingScreenModel> =
      MutableLiveData(LandingScreenModel())

  var navArguments: Bundle? = null
}
