package com.vicsapplication.app.modules.homepagescreentwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreentwo.`data`.model.HomepageScreenTwoModel
import org.koin.core.KoinComponent

class HomepageScreenTwoVM : ViewModel(), KoinComponent {
  val homepageScreenTwoModel: MutableLiveData<HomepageScreenTwoModel> =
      MutableLiveData(HomepageScreenTwoModel())

  var navArguments: Bundle? = null
}
