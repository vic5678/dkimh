package com.vicsapplication.app.modules.mainmenu.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityMainMenuBinding
import com.vicsapplication.app.modules.aboutemb.ui.AboutembActivity
import com.vicsapplication.app.modules.applicationinfo.ui.ApplicationInfoActivity
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.loginscreen.ui.LoginScreenActivity
import com.vicsapplication.app.modules.mainmenu.`data`.viewmodel.MainMenuVM
import com.vicsapplication.app.modules.termsofuseandprivacypolicy.ui.TermsOfUseAndPrivacyPolicyActivity
import kotlin.String
import kotlin.Unit

class MainMenuActivity : BaseActivity<ActivityMainMenuBinding>(R.layout.activity_main_menu) {
  private val viewModel: MainMenuVM by viewModels<MainMenuVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.mainMenuVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtLogout.setOnClickListener {
      val destIntent = LoginScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtLanguage.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtApplicationInf.setOnClickListener {
      val destIntent = ApplicationInfoActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtIDerma.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtAboutEMB.setOnClickListener {
      val destIntent = AboutembActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtHomepage.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtTermsofuse.setOnClickListener {
      val destIntent = TermsOfUseAndPrivacyPolicyActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      val destIntent = AboutembActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageClose.setOnClickListener {
      // TODO please, add your navigation code here
      finish()
    }
  }

  companion object {
    const val TAG: String = "MAIN_MENU_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, MainMenuActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
