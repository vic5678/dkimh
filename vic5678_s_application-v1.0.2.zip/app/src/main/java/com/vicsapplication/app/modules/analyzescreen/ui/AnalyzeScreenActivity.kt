package com.vicsapplication.app.modules.analyzescreen.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityAnalyzeScreenBinding
import com.vicsapplication.app.modules.analyzescreen.`data`.viewmodel.AnalyzeScreenVM
import com.vicsapplication.app.modules.resultscreen.ui.ResultScreenActivity
import kotlin.String
import kotlin.Unit

class AnalyzeScreenActivity :
    BaseActivity<ActivityAnalyzeScreenBinding>(R.layout.activity_analyze_screen) {
  private val viewModel: AnalyzeScreenVM by viewModels<AnalyzeScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.analyzeScreenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtContinue.setOnClickListener {
      val destIntent = ResultScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "ANALYZE_SCREEN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, AnalyzeScreenActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
