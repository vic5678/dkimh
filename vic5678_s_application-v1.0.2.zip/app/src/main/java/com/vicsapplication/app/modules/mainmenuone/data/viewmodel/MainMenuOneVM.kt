package com.vicsapplication.app.modules.mainmenuone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.mainmenuone.`data`.model.MainMenuOneModel
import org.koin.core.KoinComponent

class MainMenuOneVM : ViewModel(), KoinComponent {
  val mainMenuOneModel: MutableLiveData<MainMenuOneModel> = MutableLiveData(MainMenuOneModel())

  var navArguments: Bundle? = null
}
