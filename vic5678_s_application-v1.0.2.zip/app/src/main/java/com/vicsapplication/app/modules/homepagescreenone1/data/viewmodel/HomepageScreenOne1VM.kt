package com.vicsapplication.app.modules.homepagescreenone1.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreenone1.`data`.model.HomepageScreenOne1Model
import org.koin.core.KoinComponent

class HomepageScreenOne1VM : ViewModel(), KoinComponent {
  val homepageScreenOne1Model: MutableLiveData<HomepageScreenOne1Model> =
      MutableLiveData(HomepageScreenOne1Model())

  var navArguments: Bundle? = null
}
