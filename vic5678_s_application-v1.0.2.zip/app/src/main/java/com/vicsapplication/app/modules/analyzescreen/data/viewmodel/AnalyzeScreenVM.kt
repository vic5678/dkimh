package com.vicsapplication.app.modules.analyzescreen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.analyzescreen.`data`.model.AnalyzeScreenModel
import org.koin.core.KoinComponent

class AnalyzeScreenVM : ViewModel(), KoinComponent {
  val analyzeScreenModel: MutableLiveData<AnalyzeScreenModel> =
      MutableLiveData(AnalyzeScreenModel())

  var navArguments: Bundle? = null
}
