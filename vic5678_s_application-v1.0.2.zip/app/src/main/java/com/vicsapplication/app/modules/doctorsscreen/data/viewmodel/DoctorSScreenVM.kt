package com.vicsapplication.app.modules.doctorsscreen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.doctorsscreen.`data`.model.DoctorSScreenModel
import org.koin.core.KoinComponent

class DoctorSScreenVM : ViewModel(), KoinComponent {
  val doctorSScreenModel: MutableLiveData<DoctorSScreenModel> =
      MutableLiveData(DoctorSScreenModel())

  var navArguments: Bundle? = null
}
