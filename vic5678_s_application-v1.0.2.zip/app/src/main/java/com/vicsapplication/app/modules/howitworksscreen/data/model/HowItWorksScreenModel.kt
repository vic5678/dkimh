package com.vicsapplication.app.modules.howitworksscreen.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class HowItWorksScreenModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtBack: String? = MyApp.getInstance().resources.getString(R.string.lbl_back)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHowtoscan: String? = MyApp.getInstance().resources.getString(R.string.lbl_how_to_scan)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtStepCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_step_1)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLorempaspasp: String? =
      MyApp.getInstance().resources.getString(R.string.msg_press_the_butto)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLorempaspaspOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_this_button_and)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtStepCounterOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_step_2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLorempaspaspTwo: String? =
      MyApp.getInstance().resources.getString(R.string.msg_press_the_butto2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLorempaspaspThree: String? =
      MyApp.getInstance().resources.getString(R.string.msg_you_will_be_dro)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtStepCounterTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_step_3)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLorempaspaspFour: String? =
      MyApp.getInstance().resources.getString(R.string.msg_take_the_pictur)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtStepCounterThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_step_4)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTreatment: String? = MyApp.getInstance().resources.getString(R.string.msg_wait_for_the_re)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReadytoscan: String? = MyApp.getInstance().resources.getString(R.string.lbl_ready_to_scan)

)
