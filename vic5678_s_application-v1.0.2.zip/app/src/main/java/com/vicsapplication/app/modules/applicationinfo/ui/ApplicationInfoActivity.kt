package com.vicsapplication.app.modules.applicationinfo.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityApplicationInfoBinding
import com.vicsapplication.app.modules.applicationinfo.`data`.viewmodel.ApplicationInfoVM
import com.vicsapplication.app.modules.homepagescreenfive.ui.HomepageScreenFiveActivity
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import kotlin.String
import kotlin.Unit

class ApplicationInfoActivity :
    BaseActivity<ActivityApplicationInfoBinding>(R.layout.activity_application_info) {
  private val viewModel: ApplicationInfoVM by viewModels<ApplicationInfoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.applicationInfoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtIDerma.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.imageMenu.setOnClickListener {
      val destIntent = HomepageScreenFiveActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "APPLICATION_INFO_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ApplicationInfoActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
