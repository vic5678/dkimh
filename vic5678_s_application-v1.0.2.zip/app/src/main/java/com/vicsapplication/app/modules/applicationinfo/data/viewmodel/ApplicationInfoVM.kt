package com.vicsapplication.app.modules.applicationinfo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.applicationinfo.`data`.model.ApplicationInfoModel
import org.koin.core.KoinComponent

class ApplicationInfoVM : ViewModel(), KoinComponent {
  val applicationInfoModel: MutableLiveData<ApplicationInfoModel> =
      MutableLiveData(ApplicationInfoModel())

  var navArguments: Bundle? = null
}
