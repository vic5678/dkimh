package com.vicsapplication.app.modules.howitworksscreen.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHowItWorksScreenBinding
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.howitworksscreen.`data`.viewmodel.HowItWorksScreenVM
import com.vicsapplication.app.modules.shootpicturescreen.ui.ShootPictureScreenActivity
import kotlin.String
import kotlin.Unit

class HowItWorksScreenActivity :
    BaseActivity<ActivityHowItWorksScreenBinding>(R.layout.activity_how_it_works_screen) {
  private val viewModel: HowItWorksScreenVM by viewModels<HowItWorksScreenVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.howItWorksScreenVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtReadytoscan.setOnClickListener {
      val destIntent = ShootPictureScreenActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtBack.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOW_IT_WORKS_SCREEN_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HowItWorksScreenActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
