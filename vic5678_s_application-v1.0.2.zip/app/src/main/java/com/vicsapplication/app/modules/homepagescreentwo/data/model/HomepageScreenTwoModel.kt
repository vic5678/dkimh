package com.vicsapplication.app.modules.homepagescreentwo.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class HomepageScreenTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAboutEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_about_emb)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtApplicationInf: String? =
      MyApp.getInstance().resources.getString(R.string.msg_application_inf)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWhothemodelw: String? =
      MyApp.getInstance().resources.getString(R.string.msg_how_the_model_w)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTermsofUse: String? = MyApp.getInstance().resources.getString(R.string.msg_terms_of_use2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLogout: String? = MyApp.getInstance().resources.getString(R.string.lbl_logout)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMadebyEMB: String? = MyApp.getInstance().resources.getString(R.string.lbl_made_by_emb)

)
