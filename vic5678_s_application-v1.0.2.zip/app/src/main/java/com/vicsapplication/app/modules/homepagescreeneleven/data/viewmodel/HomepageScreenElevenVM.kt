package com.vicsapplication.app.modules.homepagescreeneleven.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreeneleven.`data`.model.HomepageScreenElevenModel
import org.koin.core.KoinComponent

class HomepageScreenElevenVM : ViewModel(), KoinComponent {
  val homepageScreenElevenModel: MutableLiveData<HomepageScreenElevenModel> =
      MutableLiveData(HomepageScreenElevenModel())

  var navArguments: Bundle? = null
}
