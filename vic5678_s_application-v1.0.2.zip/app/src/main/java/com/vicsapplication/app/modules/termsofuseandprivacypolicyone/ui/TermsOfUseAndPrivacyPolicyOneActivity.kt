package com.vicsapplication.app.modules.termsofuseandprivacypolicyone.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityTermsOfUseAndPrivacyPolicyOneBinding
import com.vicsapplication.app.modules.termsofuseandprivacypolicyone.`data`.viewmodel.TermsOfUseAndPrivacyPolicyOneVM
import kotlin.String
import kotlin.Unit

class TermsOfUseAndPrivacyPolicyOneActivity :
    BaseActivity<ActivityTermsOfUseAndPrivacyPolicyOneBinding>(R.layout.activity_terms_of_use_and_privacy_policy_one)
    {
  private val viewModel: TermsOfUseAndPrivacyPolicyOneVM by
      viewModels<TermsOfUseAndPrivacyPolicyOneVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.termsOfUseAndPrivacyPolicyOneVM = viewModel
  }

  override fun setUpClicks(): Unit {
  }

  companion object {
    const val TAG: String = "TERMS_OF_USE_AND_PRIVACY_POLICY_ONE_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, TermsOfUseAndPrivacyPolicyOneActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
