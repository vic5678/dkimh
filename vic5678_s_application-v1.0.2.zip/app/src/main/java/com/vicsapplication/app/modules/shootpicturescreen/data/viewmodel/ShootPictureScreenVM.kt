package com.vicsapplication.app.modules.shootpicturescreen.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.shootpicturescreen.`data`.model.ShootPictureScreenModel
import org.koin.core.KoinComponent

class ShootPictureScreenVM : ViewModel(), KoinComponent {
  val shootPictureScreenModel: MutableLiveData<ShootPictureScreenModel> =
      MutableLiveData(ShootPictureScreenModel())

  var navArguments: Bundle? = null
}
