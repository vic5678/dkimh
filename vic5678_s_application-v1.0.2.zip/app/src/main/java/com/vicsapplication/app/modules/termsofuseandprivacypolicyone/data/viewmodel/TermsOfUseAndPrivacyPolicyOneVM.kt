package com.vicsapplication.app.modules.termsofuseandprivacypolicyone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.termsofuseandprivacypolicyone.`data`.model.TermsOfUseAndPrivacyPolicyOneModel
import org.koin.core.KoinComponent

class TermsOfUseAndPrivacyPolicyOneVM : ViewModel(), KoinComponent {
  val termsOfUseAndPrivacyPolicyOneModel: MutableLiveData<TermsOfUseAndPrivacyPolicyOneModel> =
      MutableLiveData(TermsOfUseAndPrivacyPolicyOneModel())

  var navArguments: Bundle? = null
}
