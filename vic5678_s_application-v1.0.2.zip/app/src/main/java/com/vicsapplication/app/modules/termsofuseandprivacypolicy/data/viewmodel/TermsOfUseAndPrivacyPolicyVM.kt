package com.vicsapplication.app.modules.termsofuseandprivacypolicy.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.termsofuseandprivacypolicy.`data`.model.TermsOfUseAndPrivacyPolicyModel
import org.koin.core.KoinComponent

class TermsOfUseAndPrivacyPolicyVM : ViewModel(), KoinComponent {
  val termsOfUseAndPrivacyPolicyModel: MutableLiveData<TermsOfUseAndPrivacyPolicyModel> =
      MutableLiveData(TermsOfUseAndPrivacyPolicyModel())

  var navArguments: Bundle? = null
}
