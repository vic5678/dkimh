package com.vicsapplication.app.modules.homepagescreenfive.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreenfive.`data`.model.HomepageScreenFiveModel
import org.koin.core.KoinComponent

class HomepageScreenFiveVM : ViewModel(), KoinComponent {
  val homepageScreenFiveModel: MutableLiveData<HomepageScreenFiveModel> =
      MutableLiveData(HomepageScreenFiveModel())

  var navArguments: Bundle? = null
}
