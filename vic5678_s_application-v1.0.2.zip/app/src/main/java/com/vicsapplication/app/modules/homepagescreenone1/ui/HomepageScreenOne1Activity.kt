package com.vicsapplication.app.modules.homepagescreenone1.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.ActivityHomepageScreenOne1Binding
import com.vicsapplication.app.modules.homepagescreennine.ui.HomepageScreenNineActivity
import com.vicsapplication.app.modules.homepagescreenone.ui.HomepageScreenOneActivity
import com.vicsapplication.app.modules.homepagescreenone1.`data`.viewmodel.HomepageScreenOne1VM
import kotlin.String
import kotlin.Unit

class HomepageScreenOne1Activity :
    BaseActivity<ActivityHomepageScreenOne1Binding>(R.layout.activity_homepage_screen_one1) {
  private val viewModel: HomepageScreenOne1VM by viewModels<HomepageScreenOne1VM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.homepageScreenOne1VM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageMenu.setOnClickListener {
      val destIntent = HomepageScreenNineActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.txtBack.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
    binding.btnHome.setOnClickListener {
      val destIntent = HomepageScreenOneActivity.getIntent(this, null)
      startActivity(destIntent)
    }
  }

  companion object {
    const val TAG: String = "HOMEPAGE_SCREEN_ONE1ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, HomepageScreenOne1Activity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
