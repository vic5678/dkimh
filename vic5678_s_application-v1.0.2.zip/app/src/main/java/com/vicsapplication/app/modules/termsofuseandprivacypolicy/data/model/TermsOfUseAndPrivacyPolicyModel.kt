package com.vicsapplication.app.modules.termsofuseandprivacypolicy.`data`.model

import com.vicsapplication.app.R
import com.vicsapplication.app.appcomponents.di.MyApp
import kotlin.String

data class TermsOfUseAndPrivacyPolicyModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtIDerma: String? = MyApp.getInstance().resources.getString(R.string.lbl_iderma)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTermsofusean: String? =
      MyApp.getInstance().resources.getString(R.string.msg_terms_of_use_an)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDescription: String? =
      MyApp.getInstance().resources.getString(R.string.msg_terms_of_use_we)

)
