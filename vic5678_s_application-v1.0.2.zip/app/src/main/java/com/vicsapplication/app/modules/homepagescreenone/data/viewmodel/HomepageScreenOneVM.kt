package com.vicsapplication.app.modules.homepagescreenone.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.vicsapplication.app.modules.homepagescreenone.`data`.model.HomepageScreenOneModel
import org.koin.core.KoinComponent

class HomepageScreenOneVM : ViewModel(), KoinComponent {
  val homepageScreenOneModel: MutableLiveData<HomepageScreenOneModel> =
      MutableLiveData(HomepageScreenOneModel())

  var navArguments: Bundle? = null
}
