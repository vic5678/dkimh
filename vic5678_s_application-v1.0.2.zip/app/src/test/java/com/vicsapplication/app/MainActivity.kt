package com.vicsapplication.app

import com.vicsapplication.app.appcomponents.base.BaseActivity
import com.vicsapplication.app.databinding.LayoutProgressDialogBinding

class MainActivity : BaseActivity<LayoutProgressDialogBinding>(R.layout.layout_progress_dialog) {

    override fun onInitialized() {

    }

    override fun setUpClicks() {

    }
}